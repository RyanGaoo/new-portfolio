# r3f-animated-book-slider-final

![YouTube Thumbnail](https://github.com/user-attachments/assets/c6b6ea2e-2643-4d53-89b7-ee5b848de06d)

[Video tutorial](https://youtu.be/b7a_Y1Ja6js)

[Live demo](https://r3f-animated-book-slider-final.vercel.app/)

[Starter code](https://github.com/wass08/r3f-animated-book-slider-starter)
